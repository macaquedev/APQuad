#include "APQuad.h"

APQuad::APQuad(int servoType=1, uint8_t I2C_ADDR = 0x40){
  if (servoType == 0) { // MG996R Servo selected
    hipLength = 50;
    legLength = 115;
    footLength = 90;
    bodySideLength = 130;
    s.servoSet(SERVO_ALL, SERVO_SG90);
  }
}

void APQuad::begin() {
  s.begin(I2C_ADDR);
}


bool APQuad::folded(){
  return fl;
}

void APQuad::moveServo(uint8_t servoPin, int pos) {
  pos += offsets[servoPin];
  if (pos > 180) {
    pos = 180;
  }
  else if (pos < 0) {
    pos = 0;
  }
  s.servoWrite(servoPin, pos);
}

void APQuad::unfold(uint8_t servoSpeed) {
  for (uint8_t i = sleepAnkles; i >= neutralAnkles; i--) {
    moveServo(bra, 180 - i);
    moveServo(bla, i);
    moveServo(fra, i);
    moveServo(fla, 180 - i);
    delay(servoSpeed);
  }
  delay(servoSpeed*35);

  for (uint8_t i = sleepHips; i <= neutralHips; i++) {
    moveServo(brh, i);
    moveServo(blh, 180 - i);
    moveServo(frh, 180 - i);
    moveServo(flh, i);
    delay(servoSpeed);
  }

  delay(servoSpeed * 35);
  for (uint8_t i = sleepKnees; i <= neutralKnees; i++) {
    moveServo(brk, 180 - i);
    moveServo(blk, i);
    moveServo(frk, i);
    moveServo(flk, 180 - i);
    delay(servoSpeed);
  }
  fl = false;
}

void APQuad::fold(uint8_t servoSpeed) {
  for (int i = neutralKnees; i >= sleepKnees+1; i--) {
    moveServo(brk, 180 - i);
    moveServo(blk, i);
    moveServo(frk, i);
    moveServo(flk, 180 - i);
    Serial.println(i);
    delay(servoSpeed);
  }
  delay (servoSpeed * 35);
  for (uint8_t i = neutralAnkles; i <= sleepAnkles; i++) {
    moveServo(bra, 180 - i);
    moveServo(bla, i);
    moveServo(fra, i);
    moveServo(fla, 180 - i);
    delay(servoSpeed);
  }
  delay(servoSpeed*35);

  for (uint8_t i = neutralHips; i >= sleepHips; i--) {
    moveServo(brh, i);
    moveServo(blh, 180 - i);
    moveServo(frh, 180 - i);
    moveServo(flh, i);
    delay(servoSpeed);
  }
  fl = false;
}

void APQuad::stepForwardsCreepGait(uint8_t x, int y) {
  // Set delays
  // INIT FOR CREEP GAIT
  moveServo(frk, neutralKnees + kneeUp);
  moveServo(fra, neutralKnees + kneeUp);
  delay(y);
  moveServo(frh, 35);
  delay(y * 2);
  moveServo(frk, neutralKnees);
  moveServo(fra, neutralKnees);
  delay(y);
  moveServo(brk, 180 - (neutralKnees + kneeUp));
  moveServo(bra, 180 - (neutralKnees + kneeUp));
  delay(y);
  moveServo(brh, 145);
  delay(y * 2);
  moveServo(brk, 180 - neutralKnees);
  moveServo(bra, 180 - neutralKnees);
  delay(y);

  // Start Repeating
  for (uint8_t i = 1; i <= x; i++) {
    // STEP 1
    moveServo(frk, neutralKnees + kneeUp);
    moveServo(fra, neutralKnees + kneeUp);
    delay(y);
    moveServo(frh, 125);
    delay(y * 2);
    moveServo(frk, neutralKnees);
    moveServo(fra, neutralKnees);
    delay(y);

    // STEP 2
    moveServo(frh, 90);
    moveServo(brh, 90);
    moveServo(flh, 145);
    moveServo(blh, 125);
    delay(y * 2);

    // STEP 3
    moveServo(blk, neutralKnees + kneeUp);
    moveServo(bla, neutralKnees + kneeUp);
    delay(y);
    moveServo(blh, 35);
    delay(y * 2);
    moveServo(blk, neutralKnees);
    moveServo(bla, neutralKnees);
    delay(y);
    // STEP 4
    moveServo(flk, 180 - (neutralKnees + kneeUp));
    moveServo(fla, 180 - (neutralKnees + kneeUp));
    delay(y);
    moveServo(flh, 55);
    delay(y * 2);
    moveServo(flk, 180 - neutralKnees);
    moveServo(fla, 180 - neutralKnees);
    delay(y);

    // STEP 5
    moveServo(flh, 90);
    moveServo(blh, 90);
    moveServo(frh, 35);
    moveServo(brh, 55);
    delay(y * 2);
    // STEP 6
    if (i != x) {
      moveServo(brk, 180 - (neutralKnees + kneeUp));
      moveServo(bra, 180 - (neutralKnees + kneeUp));
      delay(y);
      moveServo(brh, 145);
      delay(y * 2);
      moveServo(brk, 180 - neutralKnees);
      moveServo(bra, 180 - neutralKnees);
      delay(y);
    }


  }
  moveServo(brk, 180 - (neutralKnees + kneeUp));
  moveServo(bra, 180 - (neutralKnees + kneeUp));
  delay(y);
  moveServo(brh, 180 - neutralHips);
  delay(y * 2);
  moveServo(brk, 180 - neutralKnees);
  moveServo(bra, 180 - neutralKnees);
  delay(y);
  moveServo(frk, neutralKnees + kneeUp);
  moveServo(fra, neutralKnees + kneeUp);
  delay(y);
  moveServo(frh, neutralHips);
  delay(y * 2);
  moveServo(frk, neutralKnees);
  moveServo(fra, neutralKnees);
}

void APQuad::stepBackwardsCreepGait(uint8_t x, int y) {
  // Set delays
  // INIT FOR CREEP GAIT
  moveServo(blk, neutralKnees + kneeUp);
  moveServo(bla, neutralKnees + kneeUp);
  delay(y);
  moveServo(blh, 35);
  delay(y * 2);
  moveServo(blk, neutralKnees);
  moveServo(bla, neutralKnees);
  delay(y);
  moveServo(flk, 180 - (neutralKnees + kneeUp));
  moveServo(fla, 180 - (neutralKnees + kneeUp));
  delay(y);
  moveServo(flh, 145);
  delay(y * 2);
  moveServo(flk, 180 - neutralKnees);
  moveServo(fla, 180 - neutralKnees);
  delay(y);

  // Start Repeating
  for (uint8_t i = 1; i <= x; i++) {
    // STEP 1
    moveServo(blk, neutralKnees + kneeUp);
    moveServo(bla, neutralKnees + kneeUp);
    delay(y);
    moveServo(blh, 125);
    delay(y * 2);
    moveServo(blk, neutralKnees);
    moveServo(bla, neutralKnees);
    delay(y);

    // STEP 2
    moveServo(blh, 90);
    moveServo(flh, 90);
    moveServo(brh, 145);
    moveServo(frh, 125);
    delay(y * 2);

    // STEP 3
    moveServo(frk, neutralKnees + kneeUp);
    moveServo(fra, neutralKnees + kneeUp);
    delay(y);
    moveServo(frh, 35);
    delay(y * 2);
    moveServo(frk, neutralKnees);
    moveServo(fra, neutralKnees);
    delay(y);
    // STEP 4
    moveServo(brk, 180 - (neutralKnees + kneeUp));
    moveServo(bra, 180 - (neutralKnees + kneeUp));
    delay(y);
    moveServo(brh, 55);
    delay(y * 2);
    moveServo(brk, 180 - neutralKnees);
    moveServo(bra, 180 - neutralKnees);
    delay(y);

    // STEP 5
    moveServo(brh, 90);
    moveServo(frh, 90);
    moveServo(blh, 35);
    moveServo(flh, 55);
    delay(y * 2);
    // STEP 6
    if (i != x) {
      moveServo(flk, 180 - (neutralKnees + kneeUp));
      moveServo(fla, 180 - (neutralKnees + kneeUp));
      delay(y);
      moveServo(flh, 145);
      delay(y * 2);
      moveServo(flk, 180 - neutralKnees);
      moveServo(fla, 180 - neutralKnees);
      delay(y);
    }


  }
  moveServo(flk, 180 - (neutralKnees + kneeUp));
  moveServo(fla, 180 - (neutralKnees + kneeUp));
  delay(y);
  moveServo(flh, 180 - neutralHips);
  delay(y * 2);
  moveServo(flk, 180 - neutralKnees);
  moveServo(fla, 180 - neutralKnees);
  delay(y);
  moveServo(blk, neutralKnees + kneeUp);
  moveServo(bla, neutralKnees + kneeUp);
  delay(y);
  moveServo(blh, neutralHips);
  delay(y * 2);
  moveServo(blk, neutralKnees);
  moveServo(bla, neutralKnees);
}

void APQuad::stepRightCreepGait(uint8_t x, int y) {
  // Set delays
  // INIT FOR CREEP GAIT
  moveServo(brk, 180 - (neutralKnees + kneeUp));
  moveServo(bra, 180 - (neutralKnees + kneeUp));
  delay(y);
  moveServo(brh, 35);
  delay(y * 2);
  moveServo(brk, 180 - neutralKnees);
  moveServo(bra, 180 - neutralKnees);
  delay(y);
  moveServo(blk, neutralKnees + kneeUp);
  moveServo(bla, neutralKnees + kneeUp);
  delay(y);
  moveServo(blh, 145);
  delay(y * 2);
  moveServo(blk, neutralKnees);
  moveServo(bla, neutralKnees);
  delay(y);

  // Start Repeating
  for (uint8_t i = 1; i <= x; i++) {
    // STEP 1
    moveServo(brk, 180 - (neutralKnees + kneeUp));
    moveServo(bra, 180 - (neutralKnees + kneeUp));
    delay(y);
    moveServo(brh, 125);
    delay(y * 2);
    moveServo(brk, 180 - neutralKnees);
    moveServo(bra, 180 - neutralKnees);
    delay(y);

    // STEP 2
    moveServo(brh, 90);
    moveServo(blh, 90);
    moveServo(frh, 145);
    moveServo(flh, 125);
    delay(y * 2);

    // STEP 3
    moveServo(flk, 180 - (neutralKnees + kneeUp));
    moveServo(fla, 180 - (neutralKnees + kneeUp));
    delay(y);
    moveServo(flh, 35);
    delay(y * 2);
    moveServo(flk, 180 - neutralKnees);
    moveServo(fla, 180 - neutralKnees);
    delay(y);
    // STEP 4
    moveServo(frk, neutralKnees + kneeUp);
    moveServo(fra, neutralKnees + kneeUp);
    delay(y);
    moveServo(frh, 55);
    delay(y * 2);
    moveServo(frk, neutralKnees);
    moveServo(fra, neutralKnees);
    delay(y);

    // STEP 5
    moveServo(frh, 90);
    moveServo(flh, 90);
    moveServo(brh, 35);
    moveServo(blh, 55);
    delay(y * 2);
    // STEP 6
    if (i != x) {
      moveServo(blk, neutralKnees + kneeUp);
      moveServo(bla, neutralKnees + kneeUp);
      delay(y);
      moveServo(blh, 145);
      delay(y * 2);
      moveServo(blk, neutralKnees);
      moveServo(bla, neutralKnees);
      delay(y);
    }


  }
  moveServo(blk, neutralKnees + kneeUp);
  moveServo(bla, neutralKnees + kneeUp);
  delay(y);
  moveServo(blh, neutralHips);
  delay(y * 2);
  moveServo(blk, neutralKnees);
  moveServo(bla, neutralKnees);
  delay(y);
  moveServo(brk, 180 - (neutralKnees + kneeUp));
  moveServo(bra, 180 - (neutralKnees + kneeUp));
  delay(y);
  moveServo(brh, 180 - neutralHips);
  delay(y * 2);
  moveServo(brk, 180 - neutralKnees);
  moveServo(bra, 180 - neutralKnees);
}

void APQuad::stepLeftCreepGait(uint8_t x, int y) {
  // Set delays
  // INIT FOR CREEP GAIT
  moveServo(flk, 180 - (neutralKnees + kneeUp));
  moveServo(fla, 180 - (neutralKnees + kneeUp));
  delay(y);
  moveServo(flh, 35);
  delay(y * 2);
  moveServo(flk, 180 - neutralKnees);
  moveServo(fla, 180 - neutralKnees);
  delay(y);
  moveServo(frk, neutralKnees + kneeUp);
  moveServo(fra, neutralKnees + kneeUp);
  delay(y);
  moveServo(frh, 145);
  delay(y * 2);
  moveServo(frk, neutralKnees);
  moveServo(fra, neutralKnees);
  delay(y);

  // Start Repeating
  for (uint8_t i = 1; i <= x; i++) {
    // STEP 1
    moveServo(flk, 180 - (neutralKnees + kneeUp));
    moveServo(fla, 180 - (neutralKnees + kneeUp));
    delay(y);
    moveServo(flh, 125);
    delay(y * 2);
    moveServo(flk, 180 - neutralKnees);
    moveServo(fla, 180 - neutralKnees);
    delay(y);

    // STEP 2
    moveServo(flh, 90);
    moveServo(frh, 90);
    moveServo(blh, 145);
    moveServo(brh, 125);
    delay(y * 2);

    // STEP 3
    moveServo(brk, 180 - (neutralKnees + kneeUp));
    moveServo(bra, 180 - (neutralKnees + kneeUp));
    delay(y);
    moveServo(brh, 35);
    delay(y * 2);
    moveServo(brk, 180 - neutralKnees);
    moveServo(bra, 180 - neutralKnees);
    delay(y);
    // STEP 4
    moveServo(blk, neutralKnees + kneeUp);
    moveServo(bla, neutralKnees + kneeUp);
    delay(y);
    moveServo(blh, 55);
    delay(y * 2);
    moveServo(blk, neutralKnees);
    moveServo(bla, neutralKnees);
    delay(y);

    // STEP 5
    moveServo(blh, 90);
    moveServo(brh, 90);
    moveServo(flh, 35);
    moveServo(frh, 55);
    delay(y * 2);
    // STEP 6
    if (i != x) {
      moveServo(frk, neutralKnees + kneeUp);
      moveServo(fra, neutralKnees + kneeUp);
      delay(y);
      moveServo(frh, 145);
      delay(y * 2);
      moveServo(frk, neutralKnees);
      moveServo(fra, neutralKnees);
      delay(y);
    }


  }
  moveServo(frk, neutralKnees + kneeUp);
  moveServo(fra, neutralKnees + kneeUp);
  delay(y);
  moveServo(frh, neutralHips);
  delay(y * 2);
  moveServo(frk, neutralKnees);
  moveServo(fra, neutralKnees);
  delay(y);
  moveServo(flk, 180 - (neutralKnees + kneeUp));
  moveServo(fla, 180 - (neutralKnees + kneeUp));
  delay(y);
  moveServo(flh, 180 - neutralHips);
  delay(y * 2);
  moveServo(flk, 180 - neutralKnees);
  moveServo(fla, 180 - neutralKnees);
}

void APQuad::stepForwardsTrotGait(uint8_t x, int y) {
  moveServo(frk, neutralKnees + kneeUp);
  moveServo(fra, neutralKnees + kneeUp);
  delay(y);
  moveServo(frh, 35);
  delay(y * 2);
  moveServo(frk, neutralKnees);
  moveServo(fra, neutralKnees);
  delay(y);
  moveServo(brk, 180 - (neutralKnees + kneeUp));
  moveServo(bra, 180 - (neutralKnees + kneeUp));
  delay(y);
  moveServo(brh, 145);
  delay(y * 2);
  moveServo(brk, 180 - neutralKnees);
  moveServo(bra, 180 - neutralKnees);
  delay(y);
  for (uint8_t r = 1; r <= x; r++) {
    moveServo(frk, neutralKnees + (kneeUp >> 1));
    moveServo(fra, neutralKnees + (kneeUp >> 1));
    moveServo(bla, neutralKnees + (kneeUp >> 1));
    moveServo(blk, neutralKnees + (kneeUp >> 1));
    for (uint8_t i = 90; i <= 145; i++) {
      moveServo(flh, i);
      moveServo(brh, map(i, 90, 145, 145, 90));
      moveServo(frh, 180 - (map(i, 90, 145, 145, 90)));
      moveServo(blh, 180 - i);
      delay(y / 20);
    }
    moveServo(frk, neutralKnees);
    moveServo(fra, neutralKnees);
    moveServo(bla, neutralKnees);
    moveServo(blk, neutralKnees);

    moveServo(flk, 180 - (neutralKnees + (kneeUp >> 1)));
    moveServo(fla, 180 - (neutralKnees + (kneeUp >> 1)));
    moveServo(bra, 180 - (neutralKnees + (kneeUp >> 1)));
    moveServo(brk, 180 - (neutralKnees + (kneeUp >> 1)));
    for (uint8_t i = 145; i >= 90; i--) {
      moveServo(flh, i);
      moveServo(brh, map(i, 145, 90, 90, 145));
      moveServo(frh, 180 - (map(i, 145, 90, 90, 145)));
      moveServo(blh, 180 - i);
      delay(y / 20);
    }
    moveServo(flk, 180 - neutralKnees);
    moveServo(fla, 180 - neutralKnees);
    moveServo(bra, 180 - neutralKnees);
    moveServo(brk, 180 - neutralKnees);
    if (r != x) {
      delay(y);
    }
  }
  moveServo(brk, 180 - (neutralKnees + kneeUp));
  moveServo(bra, 180 - (neutralKnees + kneeUp));
  delay(y);
  moveServo(brh, 180 - neutralHips);
  delay(y * 2);
  moveServo(brk, 180 - neutralKnees);
  moveServo(bra, 180 - neutralKnees);
  delay(y);
  moveServo(frk, neutralKnees + kneeUp);
  moveServo(fra, neutralKnees + kneeUp);
  delay(y);
  moveServo(frh, neutralHips);
  delay(y * 2);
  moveServo(frk, neutralKnees);
  moveServo(fra, neutralKnees);

}

void APQuad::stepBackwardsTrotGait(uint8_t x, int y) {
  moveServo(blk, neutralKnees + kneeUp);
  moveServo(bla, neutralKnees + kneeUp);
  delay(y);
  moveServo(blh, 35);
  delay(y * 2);
  moveServo(blk, neutralKnees);
  moveServo(bla, neutralKnees);
  delay(y);
  moveServo(flk, 180 - (neutralKnees + kneeUp));
  moveServo(fla, 180 - (neutralKnees + kneeUp));
  delay(y);
  moveServo(flh, 145);
  delay(y * 2);
  moveServo(flk, 180 - neutralKnees);
  moveServo(fla, 180 - neutralKnees);
  delay(y);
  for (uint8_t r = 1; r <= x; r++) {
    moveServo(blk, neutralKnees + (kneeUp >> 1));
    moveServo(bla, neutralKnees + (kneeUp >> 1));
    moveServo(fra, neutralKnees + (kneeUp >> 1));
    moveServo(frk, neutralKnees + (kneeUp >> 1));
    for (uint8_t i = 90; i <= 145; i++) {
      moveServo(brh, i);
      moveServo(flh, map(i, 90, 145, 145, 90));
      moveServo(blh, 180 - (map(i, 90, 145, 145, 90)));
      moveServo(frh, 180 - i);
      delay(y / 20);
    }
    moveServo(blk, neutralKnees);
    moveServo(bla, neutralKnees);
    moveServo(fra, neutralKnees);
    moveServo(frk, neutralKnees);

    moveServo(flk, 180 - (neutralKnees + (kneeUp >> 1)));
    moveServo(fla, 180 - (neutralKnees + (kneeUp >> 1)));
    moveServo(bra, 180 - (neutralKnees + (kneeUp >> 1)));
    moveServo(brk, 180 - (neutralKnees + (kneeUp >> 1)));
    for (uint8_t i = 145; i >= 90; i--) {
      moveServo(brh, i);
      moveServo(flh, map(i, 145, 90, 90, 145));
      moveServo(blh, 180 - (map(i, 145, 90, 90, 145)));
      moveServo(frh, 180 - i);
      delay(y / 20);
    }
    moveServo(flk, 180 - neutralKnees);
    moveServo(fla, 180 - neutralKnees);
    moveServo(bra, 180 - neutralKnees);
    moveServo(brk, 180 - neutralKnees);
    if (r != x) {
      delay(y);
    }
  }
  moveServo(flk, 180 - (neutralKnees + kneeUp));
  moveServo(fla, 180 - (neutralKnees + kneeUp));
  delay(y);
  moveServo(flh, 180 - neutralHips);
  delay(y * 2);
  moveServo(flk, 180 - neutralKnees);
  moveServo(fla, 180 - neutralKnees);
  delay(y);
  moveServo(blk, neutralKnees + kneeUp);
  moveServo(bla, neutralKnees + kneeUp);
  delay(y);
  moveServo(blh, neutralHips);
  delay(y * 2);
  moveServo(blk, neutralKnees);
  moveServo(bla, neutralKnees);

}

void APQuad::stepRightTrotGait(uint8_t x, int y) {
  moveServo(brk, 180 - (neutralKnees + kneeUp));
  moveServo(bra, 180 - (neutralKnees + kneeUp));
  delay(y);
  moveServo(brh, 35);
  delay(y * 2);
  moveServo(brk, 180 - neutralKnees);
  moveServo(bra, 180 - neutralKnees);
  delay(y);
  moveServo(blk, neutralKnees + kneeUp);
  moveServo(bla, neutralKnees + kneeUp);
  delay(y);
  moveServo(blh, 145);
  delay(y * 2);
  moveServo(blk, neutralKnees);
  moveServo(bla, neutralKnees);
  delay(y);
  for (uint8_t r = 1; r <= x; r++) {
    moveServo(brk, 180 - (neutralKnees + (kneeUp >> 1)));
    moveServo(bra, 180 - (neutralKnees + (kneeUp >> 1)));
    moveServo(fla, 180 - (neutralKnees + (kneeUp >> 1)));
    moveServo(flk, 180 - (neutralKnees + (kneeUp >> 1)));
    for (uint8_t i = 90; i <= 145; i++) {
      moveServo(frh, i);
      moveServo(blh, map(i, 90, 145, 145, 90));
      moveServo(brh, 180 - (map(i, 90, 145, 145, 90)));
      moveServo(flh, 180 - i);
      delay(y / 20);
    }
    moveServo(brk, 180 - neutralKnees);
    moveServo(bra, 180 - neutralKnees);
    moveServo(fla, 180 - neutralKnees);
    moveServo(flk, 180 - neutralKnees);

    moveServo(frk, neutralKnees + (kneeUp >> 1));
    moveServo(fra, neutralKnees + (kneeUp >> 1));
    moveServo(bla, neutralKnees + (kneeUp >> 1));
    moveServo(blk, neutralKnees + (kneeUp >> 1));
    for (uint8_t i = 145; i >= 90; i--) {
      moveServo(frh, i);
      moveServo(blh, map(i, 145, 90, 90, 145));
      moveServo(brh, 180 - (map(i, 145, 90, 90, 145)));
      moveServo(flh, 180 - i);
      delay(y / 20);
    }
    moveServo(frk, neutralKnees);
    moveServo(fra, neutralKnees);
    moveServo(bla, neutralKnees);
    moveServo(blk, neutralKnees);
    if (r != x) {
      delay(y);
    }
  }
  moveServo(blk, neutralKnees + kneeUp);
  moveServo(bla, neutralKnees + kneeUp);
  delay(y);
  moveServo(blh, 180 - neutralHips);
  delay(y * 2);
  moveServo(blk, neutralKnees);
  moveServo(bla, neutralKnees);
  delay(y);
  moveServo(brk, 180 - (neutralKnees + kneeUp));
  moveServo(bra, 180 - (neutralKnees + kneeUp));
  delay(y);
  moveServo(brh, neutralHips);
  delay(y * 2);
  moveServo(brk, 180 - neutralKnees);
  moveServo(bra, 180 - neutralKnees);

}

void APQuad::stepLeftTrotGait(uint8_t x, int y) {
  moveServo(flk, 180 - (neutralKnees + kneeUp));
  moveServo(fla, 180 - (neutralKnees + kneeUp));
  delay(y);
  moveServo(flh, 35);
  delay(y * 2);
  moveServo(flk, 180 - neutralKnees);
  moveServo(fla, 180 - neutralKnees);
  delay(y);
  moveServo(frk, neutralKnees + kneeUp);
  moveServo(fra, neutralKnees + kneeUp);
  delay(y);
  moveServo(frh, 145);
  delay(y * 2);
  moveServo(frk, neutralKnees);
  moveServo(fra, neutralKnees);
  delay(y);
  for (uint8_t r = 1; r <= x; r++) {
    moveServo(brk, 180 - (neutralKnees + (kneeUp >> 1)));
    moveServo(bra, 180 - (neutralKnees + (kneeUp >> 1)));
    moveServo(fla, 180 - (neutralKnees + (kneeUp >> 1)));
    moveServo(flk, 180 - (neutralKnees + (kneeUp >> 1)));
    for (uint8_t i = 90; i <= 145; i++) {
      moveServo(blh, i);
      moveServo(frh, map(i, 90, 145, 145, 90));
      moveServo(flh, 180 - (map(i, 90, 145, 145, 90)));
      moveServo(brh, 180 - i);
      delay(y / 20);
    }
    moveServo(brk, 180 - neutralKnees);
    moveServo(bra, 180 - neutralKnees);
    moveServo(fla, 180 - neutralKnees);
    moveServo(flk, 180 - neutralKnees);

    moveServo(frk, neutralKnees + (kneeUp >> 1));
    moveServo(fra, neutralKnees + (kneeUp >> 1));
    moveServo(bla, neutralKnees + (kneeUp >> 1));
    moveServo(blk, neutralKnees + (kneeUp >> 1));
    for (uint8_t i = 145; i >= 90; i--) {
      moveServo(blh, i);
      moveServo(frh, map(i, 145, 90, 90, 145));
      moveServo(flh, 180 - (map(i, 145, 90, 90, 145)));
      moveServo(brh, 180 - i);
      delay(y / 20);
    }
    moveServo(frk, neutralKnees);
    moveServo(fra, neutralKnees);
    moveServo(bla, neutralKnees);
    moveServo(blk, neutralKnees);
    if (r != x) {
      delay(y);
    }
  }
  moveServo(frk, neutralKnees + kneeUp);
  moveServo(fra, neutralKnees + kneeUp);
  delay(y);
  moveServo(frh, 180 - neutralHips);
  delay(y * 2);
  moveServo(frk, neutralKnees);
  moveServo(fra, neutralKnees);
  delay(y);
  moveServo(flk, 180 - (neutralKnees + kneeUp));
  moveServo(fla, 180 - (neutralKnees + kneeUp));
  delay(y);
  moveServo(flh, neutralHips);
  delay(y * 2);
  moveServo(flk, 180 - neutralKnees);
  moveServo(fla, 180 - neutralKnees);

}

void APQuad::raiseBody(int x, int y) {
  if (neutralKnees + x > 180) {
    x = 180 - neutralKnees;
  }
  if (neutralKnees + x < 1) {
    x = 1 - neutralKnees;
  }
  if (x > 0) {
    for (uint8_t i = neutralKnees; i <= neutralKnees + x; i++) {
      moveServo(blk, i);
      moveServo(brk, 180 - i);
      moveServo(frk, i);
      moveServo(flk, 180 - i);
      moveServo(bla, i);
      moveServo(bra, 180 - i);
      moveServo(fra, i);
      moveServo(fla, 180 - i);
      delay(y);
    }
    neutralKnees = neutralKnees + x;
    neutralAnkles = neutralAnkles + x;
  }
  else {
    for (uint8_t i = neutralKnees; i >= neutralKnees + x; i--) {
      moveServo(blk, i);
      moveServo(brk, 180 - i);
      moveServo(frk, i);
      moveServo(flk, 180 - i);
      moveServo(bla, i);
      moveServo(bra, 180 - i);
      moveServo(fra, i);
      moveServo(fla, 180 - i);
      delay(y);
    }
    neutralKnees = neutralKnees + x;
    neutralAnkles = neutralAnkles + x;
  }
}



void APQuad::squat(uint8_t x) {
  uint8_t cnn = neutralKnees;
  raiseBody(180 - neutralKnees, 5);
  delay(1000);
  for (uint8_t i = 1; i <= x; i++) {
    raiseBody(-70, 5);
    delay(400);
    raiseBody(70, 5);
    delay(400);
  }
  delay(1000);
  raiseBody(110 - neutralKnees, 5);
}

void APQuad::turnRight(uint8_t x, int y) {
  for (uint8_t i = 1; i <= x; i++) {
    moveServo(frk, neutralKnees + (kneeUp >> 1));
    moveServo(fra, neutralKnees + (kneeUp >> 1));
    moveServo(blk, neutralKnees + (kneeUp >> 1));
    moveServo(bla, neutralKnees + (kneeUp >> 1));
    delay(y);
    moveServo(blh, 45);
    moveServo(frh, 45);
    delay(y);
    moveServo(frk, neutralKnees);
    moveServo(fra, neutralKnees);
    moveServo(blk, neutralKnees);
    moveServo(bla, neutralKnees);
    delay(y);
    moveServo(flk, 180 - (neutralKnees + (kneeUp >> 1)));
    moveServo(fla, 180 - (neutralKnees + (kneeUp >> 1)));
    moveServo(brk, 180 - (neutralKnees + (kneeUp >> 1)));
    moveServo(bra, 180 - (neutralKnees + (kneeUp >> 1)));
    delay(y);
    moveServo(flh, 45);
    moveServo(brh, 45);
    delay(y);
    moveServo(flk, 180 - neutralKnees);
    moveServo(fla, 180 - neutralKnees);
    moveServo(brk, 180 - neutralKnees);
    moveServo(bra, 180 - neutralKnees);

    delay(y);
    moveServo(blh, neutralHips);
    moveServo(brh, 180 - neutralHips);
    moveServo(flh, 180 - neutralHips);
    moveServo(frh, neutralHips);
    delay(y);
  }
}

void APQuad::turnLeft(uint8_t x, int y) {
  for (uint8_t i = 1; i <= x; i++) {
    moveServo(frk, neutralKnees + (kneeUp >> 1));
    moveServo(fra, neutralKnees + (kneeUp >> 1));
    moveServo(blk, neutralKnees + (kneeUp >> 1));
    moveServo(bla, neutralKnees + (kneeUp >> 1));
    delay(y);
    moveServo(blh, 135);
    moveServo(frh, 135);
    delay(y);
    moveServo(frk, neutralKnees);
    moveServo(fra, neutralKnees);
    moveServo(blk, neutralKnees);
    moveServo(bla, neutralKnees);
    delay(y);
    moveServo(flk, 180 - (neutralKnees + (kneeUp >> 1)));
    moveServo(fla, 180 - (neutralKnees + (kneeUp >> 1)));
    moveServo(brk, 180 - (neutralKnees + (kneeUp >> 1)));
    moveServo(bra, 180 - (neutralKnees + (kneeUp >> 1)));
    delay(y);
    moveServo(flh, 135);
    moveServo(brh, 135);
    delay(y);
    moveServo(flk, 180 - neutralKnees);
    moveServo(fla, 180 - neutralKnees);
    moveServo(brk, 180 - neutralKnees);
    moveServo(bra, 180 - neutralKnees);

    delay(y);
    moveServo(blh, neutralHips);
    moveServo(brh, 180 - neutralHips);
    moveServo(flh, 180 - neutralHips);
    moveServo(frh, neutralHips);
    delay(y);
  }
}

void APQuad::pressUp(uint8_t x) {
  uint8_t currentNeutralKnees = neutralKnees;
  raiseBody(90 - neutralKnees, 10);
  for (uint8_t i = neutralAnkles; i >= sleepAnkles + 1; i--) {
    moveServo(bla, i);
    moveServo(bra, 180 - i);
    moveServo(fra, i);
    moveServo(fla, 180 - i);
    delay(10);
  }
  for (uint8_t i = 90; i <= 145; i++) {
    moveServo(frh, 180 - i);
    moveServo(brh, 180 - i);
    moveServo(blh, i);
    moveServo(flh, i);
    delay(10);
  }
  for (uint8_t i = sleepAnkles; i <= neutralAnkles; i++) {
    moveServo(bla, i);
    moveServo(bra, 180 - i);
    moveServo(fra, i);
    moveServo(fla, 180 - i);
    delay(10);
  }
  delay(1000);

  // Robot is in pressup position.

  for (uint8_t i = 1; i <= x; i++) {
    // PRESS UP

    for (uint8_t i = neutralKnees; i <= 170; i++) {
      moveServo(fra, i);
      moveServo(frk, i);
      moveServo(fla, 180 - i);
      moveServo(flk, 180 - i);
      delay(5);
    }

    // GO DOWN

    for (uint8_t i = 170; i >= neutralKnees + 20; i--) {
      moveServo(fra, i);
      moveServo(frk, i);
      moveServo(fla, 180 - i);
      moveServo(flk, 180 - i);
      delay(5);
    }
  }

  for (uint8_t i = neutralKnees + 20; i >= neutralKnees; i--) {
    moveServo(fra, i);
    moveServo(frk, i);
    moveServo(fla, 180 - i);
    moveServo(flk, 180 - i);
    delay(5);
  }
  // Robot has done pressups
  delay(1000);
  for (uint8_t i = neutralAnkles; i >= sleepAnkles + 1; i--) {
    moveServo(bla, i);
    moveServo(bra, 180 - i);
    moveServo(fra, i);
    moveServo(fla, 180 - i);
    delay(10);
  }
  for (uint8_t i = 145; i >= 90; i--) {
    moveServo(frh, 180 - i);
    moveServo(brh, 180 - i);
    moveServo(blh, i);
    moveServo(flh, i);
    delay(10);
  }
  for (uint8_t i = sleepAnkles + 1; i <= neutralAnkles; i++) {
    moveServo(bla, i);
    moveServo(bra, 180 - i);
    moveServo(fra, i);
    moveServo(fla, 180 - i);
    delay(10);
  }
  raiseBody(currentNeutralKnees - neutralKnees, 10);

}
