#ifndef APQUAD_H
#define APQUAD_H
#include "Arduino.h"
#include "iarduino_MultiServo.h"

namespace ServoTypes {
const uint8_t MG996R = 0;
const uint8_t SG90 = 1;
}


class APQuad {
  public:
    APQuad(int servoType=1, uint8_t I2C_ADDR = 0x40);
    void                  begin();
    void                  moveServo(uint8_t servoPin, int pos);

    bool                  folded();
    void                  unfold(uint8_t servoSpeed);
    void                  fold(uint8_t servoSpeed);

    void                  stepForwardsCreepGait(uint8_t x, int y);
    void                  stepBackwardsCreepGait(uint8_t x, int y);
    void                  stepRightCreepGait(uint8_t x, int y);
    void                  stepLeftCreepGait(uint8_t x, int y);

    void                  stepForwardsTrotGait(uint8_t x, int y);
    void                  stepBackwardsTrotGait(uint8_t x, int y);
    void                  stepRightTrotGait(uint8_t x, int y);
    void                  stepLeftTrotGait(uint8_t x, int y);

    void                  turnRight(uint8_t x, int y);
    void                  turnLeft(uint8_t x, int y);

    void                  raiseBody(int x, int y);
    void                  squat(uint8_t x);
    void                  pressUp(uint8_t x);

  private:

    iarduino_MultiServo   s;
    uint8_t               I2C_ADDR = 0x40;
    uint8_t               hipLength;
    uint8_t               legLength;
    uint8_t               footLength;
    uint8_t               bodySideLength;

    uint8_t               neutralKnees = 110;
    uint8_t               neutralAnkles = 110;
    const uint8_t         neutralHips = 90;
    
    const uint8_t         sleepHips = 45;
    const uint8_t         sleepKnees = 0;
    const uint8_t         sleepAnkles = 180;

    bool                  fl = true;
    int8_t                kneeUp = -44;
    
    const uint8_t         fla = 0;
    const uint8_t         flk = 1;
    const uint8_t         flh = 2;

    const uint8_t         fra = 3;
    const uint8_t         frk = 4;
    const uint8_t         frh = 5;

    const uint8_t         bla = 6;
    const uint8_t         blk = 7;
    const uint8_t         blh = 8;

    const uint8_t         bra = 9;
    const uint8_t         brk = 10;
    const uint8_t         brh = 11;

    const uint8_t         offsets[12] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};



};

#endif